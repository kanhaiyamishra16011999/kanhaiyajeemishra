# CodeIgniter 3.x Restful API Library Demo Application

CodeIgniter Restful API Controller - Easily build REST API with Token Authorization

[Watch Videos](https://www.youtube.com/watch?v=sTeyi3c3BLk&list=PLmrTMUhqzS3itcXhLWTm-NLdAArstfZ6Z)

# Using

* PHP 5.6.8
* CodeIgniter 3.9
* Restful API Library :- http://bit.ly/codeigniter-api
* REST API Debugging Tools for Developing APIs https://insomnia.rest/
* CodeIgniter Documentation :- https://www.codeigniter.com/user_guide
